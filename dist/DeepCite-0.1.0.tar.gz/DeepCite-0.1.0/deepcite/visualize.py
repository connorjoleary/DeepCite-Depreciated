def visualize(nodes):
    for node in nodes:
        print(node.site)
        print(node.text)
        print()